def geometricPerspective(stateMsg):
	print(stateMsg)
