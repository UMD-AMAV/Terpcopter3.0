#
# Author: Siddhesh Rane
import rospy
import cv2
import numpy as np
import matplotlib.pyplot as plt
from std_msgs.msg import Bool
from cv_bridge import CvBridge, CvBridgeError
from _feedback import feedback




def nothing(x):
    pass
def tuner(frame,detector_obst):
    FlagIP = rospy.Publisher('targetObst',Bool,queue_size=10)
    # cap = cv2.VideoCapture(0)
    # cv2.namedWindow("Trackbars",)
    # cv2.createTrackbar("lh","Trackbars",0,179,nothing)
    # cv2.createTrackbar("ls","Trackbars",0,255,nothing)
    # cv2.createTrackbar("lv","Trackbars",0,255,nothing)
    # cv2.createTrackbar("uh","Trackbars",179,179,nothing)
    # cv2.createTrackbar("us","Trackbars",255,255,nothing)
    # cv2.createTrackbar("uv","Trackbars",255,255,nothing)
    # while True:
    # ret, frame = cap.read()

    #frame = cv2.imread('candy.jpg')
    height, width = frame.shape[:2]
    # frame = cv2.resize(frame,(width/2, height/2), interpolation = cv2.INTER_CUBIC)
    hsv = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    kernel = np.ones((5,5), np.uint8)

    # lh = cv2.getTrackbarPos("lh","Trackbars")
    # ls = cv2.getTrackbarPos("ls","Trackbars")
    # lv = cv2.getTrackbarPos("lv","Trackbars")
    # uh = cv2.getTrackbarPos("uh","Trackbars")
    # us = cv2.getTrackbarPos("us","Trackbars")
    # uv = cv2.getTrackbarPos("uv","Trackbars")

    # l_pink = np.array([lh,ls,lv])
    # u_pink = np.array([uh,us,uv])
    l_pink_tuned = np.array([123,10,45])
    u_pink_tuned = np.array([180,255,255])
    mask = cv2.inRange(hsv, l_pink_tuned, u_pink_tuned)
    # mask = 255-mask
    mask_erode = cv2.erode(mask, kernel, iterations = 2)
    result = cv2.bitwise_and(frame,frame,mask=mask)

    keypoints = detector_obst.detect(result)

    draw = cv2.drawKeypoints(frame, keypoints, np.array([]), (0,0,0), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    c = False
    if (keypoints!=[]):
        # print(len(keypoints))
        (x,y) = keypoints[0].pt
        x = int(x)
        y= int(y)
        cv2.circle(frame,(x,y), 12 ,(128,0,128),-1) #to locate the centre of frame which we assume to be quad
        c = True

    FlagIP.publish(c)


    # print("Lower Bound: ", l_pink)
    # print("Upper Bound: ", u_pink)
    cv2.imshow("Obstacle",frame)
    # cv2.imshow("mask",mask)
    # cv2.imshow("result",result)
    # cv2.imshow("maskEroded", mask_erode)
    # key = cv2.waitKey(1)
    # if key == 27:
    #     break
    #     cap.release()
    #     cv2.destroyAllWindows()
