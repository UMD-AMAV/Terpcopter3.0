#!/usr/bin/env python
# Copyright (c) 2019, AMAV Team.
# All rights reserved.
## Image processing code for the target detection and alignment

import rospy
import cv2
import numpy as np
import math
from std_msgs.msg import String
from std_msgs.msg import Float32
from sensor_msgs.msg import Image
from sensor_msgs.msg import CompressedImage
from cv_bridge import CvBridge, CvBridgeError
from _feedback import feedback
from _stateEstimate import stateEstimate
from _targetPose import targetPose
import redDotDetect
import autoCannyVideo
from yawControl import yaw_control
#image callback function, no need to change this

i = 0
hError = 0
vError = 0
err_yaw_sum = 0
est_time = 0
def callbackImage(data):
    #rospy.loginfo('I heard ')
    #cv_image = CvBridge().imgmsg_to_cv2(data, #desired_encoding="passthrough")
    np_array = np.fromstring(data.data,np.uint8)
    cv_image = cv2.imdecode(np_array, cv2.IMREAD_COLOR)
    #redDotDetect.imageProcessing(cv_image)
    autoCannyVideo.objectDetection(cv_image)
def callbackState(data):
    stateVideo.geometricPerspective(data)
#subscriber function which subscribes to the camera topic

def callbackRed(data):
    global hError,vError
    hError = data.u
    vError = data.v


def callbackYaw(data):
    global i
    global err_yaw_sum
    global est_time
    global hError
    global vError
    yaw_est = data.yaw
    print('yaw estimate:',yaw_est)
    # est_time = data.time
#     curr_time = rospy.Time.now()
    # hError = hError
    if hError==0:
        hError = 0.000001
    # if vError==800:
        # vError = 0.00000001
    print ('errors:',hError,vError)

    yaw_des = math.degrees(math.atan(vError/hError)) + 90

    print('Yaw_des',yaw_des)
    # yaw_des = 1.5
    err_yaw = yaw_est - yaw_des
    if i == 0:
        err_yaw_sum=0
        est_time = rospy.Time.now()
        i=1
    est_time, stick_cmd,err_yaw_sum = yaw_pid(err_yaw, err_yaw_sum ,est_time)
    print('Yaw:',stick_cmd)
    print('#################################################################################')
    # yaw_est = from state estimate
#     dt = curr_time -
#     err_yaw = yaw_est - yaw_des
#     err_yaw_dot = (yaw_est - yaw_des)/dt
#     # err_yaw_sum += err_yaw_sum*dt
#
#
#     u = -kp*err_yaw -kd*err_yaw_dot
#     time_last = now = rospy.Time.now()


def imageSubscriber():
    rospy.init_node('imageSubscriber', anonymous=True)
    rospy.Subscriber('/terpcopter/cameras/forward/image/compressed', CompressedImage, callbackImage)
    # rospy.Subscriber('/stateEstimate', stateEstimate, callbackState)
    # spin() simply keeps python from exiting until this node is stopped
    rospy.Subscriber('targetPose',targetPose,callbackRed)
    rospy.Subscriber('/stateEstimate',stateEstimate,callbackYaw)

    rospy.spin()

# this is the function where we can make changes to perform image processing tasks
def yaw_pid(err_yaw,err_yaw_sum, prev_time):
    curr_time = rospy.Time.now()
    dt = curr_time - prev_time
    print(type(dt))
    err_yaw_dot = err_yaw
    err_yaw_sum += err_yaw
    kp = 1
    kd = 0
    ki = 0
    yawCmd = -kp*err_yaw -kd*err_yaw_dot -ki*err_yaw_sum
    print('error in yaw:',err_yaw)
    pub = rospy.Publisher('yawSetpoint', Float32, queue_size=10)
    # pub = rospy.Publisher('yawSetpoint', Float32, queue_size=10)

    #rospy.init_node('yawCmd', anonymous=True)
    # rospy.Subscriber('targetPose', targetPose, callbackFB)
    rate = rospy.Rate(10) # 10hz
    #while not rospy.is_shutdown():
    pub.publish(yawCmd)
    rate.sleep()
    return curr_time, yawCmd, err_yaw_sum



# def yawPublisher():
#     pub = rospy.Publisher('Yaw', float32, queue_size=10)
#     rospy.init_node('yawCmd', anonymous=True)
#     # rospy.Subscriber('targetPose', targetPose, callbackFB)
#     rate = rospy.Rate(10) # 10hz
#     while not rospy.is_shutdown():
#         time, yawCmd, error_yaw = yaw_pid()
#         image_message = CvBridge().cv2_to_imgmsg(frame, encoding="passthrough")
#         pub.publish(image_message)
#         rate.sleep()
# main loop
if __name__ == '__main__':

    hError = 0.000000001
    imageSubscriber()
